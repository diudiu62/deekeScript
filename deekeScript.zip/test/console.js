console.log(2);
console.error(3);
console.debug(4);
console.info(5);
console.warn(6);
