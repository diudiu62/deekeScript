console.log(Encrypt.md5('DeekeScript'));//输出：82e431569749c90ab31cfac2a9a3c4c3
console.log(Encrypt.base64Encode('DeekeScript'));//输出：82e431569749c90ab31cfac2a9a3c4c3

console.log(Encrypt.base64Decode('RGVla2VTY3JpcHQ='));