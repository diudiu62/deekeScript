Engines.executeScriptStr("My first DeekeScript", "console.log('My first DeekeScript');");

Engines.executeScriptStr("console.log('My first DeekeScript');");

Engines.closeAll();
