console.log(Device.getUuid());

console.log(Device.createUuid());

console.log(Device.getUuid());


console.log(Storage.get("uuid"));

Device.getToken();
Device.getAttr('token');
