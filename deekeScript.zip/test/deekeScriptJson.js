DeekeScriptJson.setDeekeScriptJsonGroup("");

DeekeScriptJson.setSettingLists("str");

DeekeScriptJson.toJson();
