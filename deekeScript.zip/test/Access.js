
Access.isBackgroundAlertEnabled();
Access.isAccessibilityServiceEnabled();
Access.isFloatWindowsEnabled();
Access.isMediaProjectionEnable();

Access.openAccessibilityServiceSetting();
Access.openFloatWindowsSetting();
Access.openBackgroundAlertSetting();
Access.openMediaProjectionSetting();