

let a = java.lang.System.currentTimeMillis();
console.log(a);


