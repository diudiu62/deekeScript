

let res = Http.getHeaders("https://home.deeke.top/dkee/config", {"content-type": "json"});
console.log(res);
