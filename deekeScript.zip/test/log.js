

Log.log(10);
// Log.info(11);
// Log.error(12);
// Log.warn(13);
// Log.debug(14);

let filename = Log.getFileDir("myfile.log");
console.log(filename);
