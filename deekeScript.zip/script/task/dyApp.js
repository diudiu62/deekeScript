let e = {
    getName() {
        return "appName";
    }
};

module.exports = e;