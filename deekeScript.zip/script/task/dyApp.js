const dyApp = {
    getName(){
        return "appName";
    }
}

module.exports = dyApp;
