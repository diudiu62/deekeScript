function a1_0x3322(_0x5cb5fd, _0x3ec8e6) {
    var _0xebe046 = a1_0xebe0();
    return a1_0x3322 = function (_0x332208, _0x537273) {
        _0x332208 = _0x332208 - 0x156;
        var _0x41069c = _0xebe046[_0x332208];
        return _0x41069c;
    }, a1_0x3322(_0x5cb5fd, _0x3ec8e6);
}
(function (_0x19dfbc, _0x3341df) {
    var _0x5b75d2 = a1_0x3322, _0x2121f9 = _0x19dfbc();
    while (!![]) {
        try {
            var _0x1d8f0a = parseInt(_0x5b75d2(0x15a)) / 0x1 + -parseInt(_0x5b75d2(0x158)) / 0x2 * (parseInt(_0x5b75d2(0x15b)) / 0x3) + -parseInt(_0x5b75d2(0x15e)) / 0x4 * (parseInt(_0x5b75d2(0x156)) / 0x5) + -parseInt(_0x5b75d2(0x159)) / 0x6 + -parseInt(_0x5b75d2(0x15f)) / 0x7 + -parseInt(_0x5b75d2(0x160)) / 0x8 + parseInt(_0x5b75d2(0x157)) / 0x9;
            if (_0x1d8f0a === _0x3341df)
                break;
            else
                _0x2121f9['push'](_0x2121f9['shift']());
        } catch (_0x5366d1) {
            _0x2121f9['push'](_0x2121f9['shift']());
        }
    }
}(a1_0xebe0, 0x32224), ((() => {
    'use strict';
    var _0x3b02fb = a1_0x3322;
    var _0x14deba = [
            0x1,
            0x2,
            0x3
        ], _0x40f163 = _0x14deba[-0x1];
    function _0x4eadc8() {
        var _0x2b4117 = a1_0x3322, _0x394165 = {};
        console[_0x2b4117(0x15c)](_0x394165[_0x2b4117(0x15d)]());
    }
    console[_0x3b02fb(0x15c)](_0x14deba), _0x4eadc8();
})()));
function a1_0xebe0() {
    var _0x2b9bde = [
        '465543sIPnfJ',
        'log',
        'someMethod',
        '4xUmCWh',
        '2414503CQlGzt',
        '2869704pQlmnv',
        '1319595jTfBEC',
        '12821121yBAtau',
        '2wmgXiI',
        '2170026uRAnII',
        '265192Xbrwbf'
    ];
    a1_0xebe0 = function () {
        return _0x2b9bde;
    };
    return a1_0xebe0();
}
//# sourceMappingURL=task\test.js.map
//# sourceMappingURL=task\test.js.map