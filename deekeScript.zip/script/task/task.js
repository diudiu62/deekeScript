function a1_0x3231(_0x2e2169, _0x582089) {
    var _0xe81045 = a1_0xe810();
    return a1_0x3231 = function (_0x32312a, _0x32aa9d) {
        _0x32312a = _0x32312a - 0x102;
        var _0x237e9a = _0xe81045[_0x32312a];
        return _0x237e9a;
    }, a1_0x3231(_0x2e2169, _0x582089);
}
function a1_0xe810() {
    var _0x439802 = [
        '1331967vNmhqM',
        '12653910KUHiFT',
        '1924060ekZgEj',
        'run',
        '2861961jtgIfn',
        'intoApp',
        'log',
        'backApp',
        '13815Ejzmbi',
        '6HehOzB',
        '2984OMOrGM',
        '4154646uwxdtu',
        '5ichVLj',
        '196966wkGmpA'
    ];
    a1_0xe810 = function () {
        return _0x439802;
    };
    return a1_0xe810();
}
(function (_0x596b69, _0x3dba50) {
    var _0x7fd59e = a1_0x3231, _0x8db181 = _0x596b69();
    while (!![]) {
        try {
            var _0x3b4d90 = parseInt(_0x7fd59e(0x10e)) / 0x1 * (-parseInt(_0x7fd59e(0x104)) / 0x2) + -parseInt(_0x7fd59e(0x109)) / 0x3 + parseInt(_0x7fd59e(0x107)) / 0x4 + -parseInt(_0x7fd59e(0x103)) / 0x5 * (-parseInt(_0x7fd59e(0x102)) / 0x6) + parseInt(_0x7fd59e(0x105)) / 0x7 + -parseInt(_0x7fd59e(0x10f)) / 0x8 * (parseInt(_0x7fd59e(0x10d)) / 0x9) + parseInt(_0x7fd59e(0x106)) / 0xa;
            if (_0x3b4d90 === _0x3dba50)
                break;
            else
                _0x8db181['push'](_0x8db181['shift']());
        } catch (_0x3e0243) {
            _0x8db181['push'](_0x8db181['shift']());
        }
    }
}(a1_0xe810, 0x7cec8), ((() => {
    'use strict';
    var _0x2d8e91 = a1_0x3231;
    var _0xc293f2 = {
        'intoApp': function () {
        },
        'backApp': function () {
        },
        'task': function () {
        },
        'run': function () {
            var _0x15b679 = a1_0x3231;
            try {
                this[_0x15b679(0x10a)](), this['task']();
            } catch (_0x3639dc) {
                console[_0x15b679(0x10b)](_0x3639dc), this[_0x15b679(0x10c)]();
            }
        }
    };
    _0xc293f2[_0x2d8e91(0x108)]();
})()));
//# sourceMappingURL=task/task.js.map
//# sourceMappingURL=task.js.map