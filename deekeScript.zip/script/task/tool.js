function a1_0x224a() {
    var _0x5d1d10 = [
        '71GuLdmx',
        '4296xpyGoc',
        'ToUMr',
        '2131386WbTpcz',
        '15856kWrKLl',
        '1687bitdPv',
        '请编写业务代码',
        '655638yEFcSm',
        '91805mcpiYV',
        '3384666lyPAfx',
        '2359960rgMWCY',
        'show',
        'run'
    ];
    a1_0x224a = function () {
        return _0x5d1d10;
    };
    return a1_0x224a();
}
function a1_0x521d(_0xe5e7fb, _0x236adc) {
    var _0x224aa2 = a1_0x224a();
    return a1_0x521d = function (_0x521de4, _0x4ce96f) {
        _0x521de4 = _0x521de4 - 0x90;
        var _0x3d63d1 = _0x224aa2[_0x521de4];
        return _0x3d63d1;
    }, a1_0x521d(_0xe5e7fb, _0x236adc);
}
(function (_0x3aed46, _0x1e9c67) {
    var _0x3a40ab = a1_0x521d, _0x21d4dd = _0x3aed46();
    while (!![]) {
        try {
            var _0x1ac7dc = parseInt(_0x3a40ab(0x90)) / 0x1 * (parseInt(_0x3a40ab(0x94)) / 0x2) + -parseInt(_0x3a40ab(0x97)) / 0x3 + parseInt(_0x3a40ab(0x9a)) / 0x4 + -parseInt(_0x3a40ab(0x98)) / 0x5 + -parseInt(_0x3a40ab(0x93)) / 0x6 + -parseInt(_0x3a40ab(0x95)) / 0x7 * (-parseInt(_0x3a40ab(0x91)) / 0x8) + -parseInt(_0x3a40ab(0x99)) / 0x9;
            if (_0x1ac7dc === _0x1e9c67)
                break;
            else
                _0x21d4dd['push'](_0x21d4dd['shift']());
        } catch (_0x53bb52) {
            _0x21d4dd['push'](_0x21d4dd['shift']());
        }
    }
}(a1_0x224a, 0x4cae3), ((() => {
    'use strict';
    var _0x1179ba = a1_0x521d, _0xe3c95b = { 'ToUMr': _0x1179ba(0x96) };
    var _0xe64ca8 = {
        'intoApp': function () {
        },
        'backApp': function () {
        },
        'task': function () {
        },
        'run': function () {
            var _0x4863bc = _0x1179ba;
            FloatDialogs[_0x4863bc(0x9b)]('提示', _0xe3c95b[_0x4863bc(0x92)]);
        }
    };
    _0xe64ca8[_0x1179ba(0x9c)]();
})()));
//# sourceMappingURL=task/tool.js.map
//# sourceMappingURL=tool.js.map