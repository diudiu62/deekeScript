const a4_0xdca837 = a4_0x50f2;
function a4_0x222a() {
    const _0x4755a7 = [
        '\x72\x75\x6e',
        '\x31\x30\x34\x30\x39\x33\x30\x51\x64\x63\x69\x61\x6f',
        '\x31\x36\x34\x39\x32\x37\x63\x45\x48\x4c\x64\x70',
        '\x49\x79\x6e\x6f\x59',
        '\x73\x68\x6f\x77',
        '\x32\x32\x32\x36\x38\x31\x35\x6e\x41\x79\x4b\x43\x6d',
        '\x34\x34\x30\x36\x33\x36\x55\x52\x70\x6a\x7a\x62',
        '\x32\x32\x32\x30\x32\x37\x33\x45\x4b\x50\x55\x6d\x50',
        '\x31\x33\x38\x31\x38\x32\x4d\x67\x6c\x78\x4d\x5a',
        '\u8bf7\u7f16\u5199\u4e1a\u52a1\u4ee3\u7801',
        '\x32\x32\x38\x66\x58\x4d\x76\x53\x76',
        '\x38\x50\x72\x4c\x7a\x54\x77',
        '\x38\x30\x44\x6e\x6a\x66\x66\x57',
        '\x33\x56\x50\x6c\x66\x64\x75',
        '\x37\x34\x35\x35\x38\x38\x62\x4c\x72\x6c\x4a\x62'
    ];
    a4_0x222a = function () {
        return _0x4755a7;
    };
    return a4_0x222a();
}
function a4_0x50f2(_0x50cafc, _0x427daa) {
    const _0x222a0c = a4_0x222a();
    return a4_0x50f2 = function (_0x50f232, _0x4a94d4) {
        _0x50f232 = _0x50f232 - 0xf7;
        let _0x1d3ad2 = _0x222a0c[_0x50f232];
        return _0x1d3ad2;
    }, a4_0x50f2(_0x50cafc, _0x427daa);
}
(function (_0x111885, _0x496138) {
    const _0x2055f0 = a4_0x50f2, _0x2b8583 = _0x111885();
    while (!![]) {
        try {
            const _0x17ab3e = parseInt(_0x2055f0(0x103)) / 0x1 + parseInt(_0x2055f0(0xfe)) / 0x2 * (parseInt(_0x2055f0(0xfb)) / 0x3) + parseInt(_0x2055f0(0xfc)) / 0x4 + parseInt(_0x2055f0(0x102)) / 0x5 + parseInt(_0x2055f0(0xf8)) / 0x6 * (-parseInt(_0x2055f0(0xff)) / 0x7) + -parseInt(_0x2055f0(0xf9)) / 0x8 * (parseInt(_0x2055f0(0x104)) / 0x9) + parseInt(_0x2055f0(0xfa)) / 0xa * (parseInt(_0x2055f0(0x105)) / 0xb);
            if (_0x17ab3e === _0x496138)
                break;
            else
                _0x2b8583['push'](_0x2b8583['shift']());
        } catch (_0x4153e3) {
            _0x2b8583['push'](_0x2b8583['shift']());
        }
    }
}(a4_0x222a, 0x869ae));
let myTask = {
    '\x69\x6e\x74\x6f\x41\x70\x70'() {
    },
    '\x62\x61\x63\x6b\x41\x70\x70'() {
    },
    '\x74\x61\x73\x6b'() {
    },
    '\x72\x75\x6e'() {
        const _0x1d83e8 = a4_0x50f2, _0x474f8f = {};
        _0x474f8f[_0x1d83e8(0x100)] = _0x1d83e8(0xf7);
        const _0x31cf09 = _0x474f8f;
        FloatDialogs[_0x1d83e8(0x101)]('\u63d0\u793a', _0x31cf09['\x49\x79\x6e\x6f\x59']);
    }
};
myTask[a4_0xdca837(0xfd)]();
//# sourceMappingURL=tool.js.map