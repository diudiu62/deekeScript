let a = {
    intoApp() {},
    backApp() {},
    task() {},
    run() {
        FloatDialogs.show("提示", "请编写业务代码");
    }
};

a.run();