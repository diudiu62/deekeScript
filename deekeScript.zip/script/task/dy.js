const a1_0x53aa7a = a1_0x106e;
function a1_0x17a5() {
    const _0x481597 = [
        '\u8bf7\u7f16\u5199\u4e1a\u52a1\u4ee3\u7801',
        '\x33\x39\x37\x35\x32\x31\x74\x6b\x64\x4a\x6b\x72',
        '\x37\x32\x75\x4e\x66\x6d\x76\x59',
        '\x32\x39\x31\x37\x34\x35\x33\x69\x53\x73\x54\x43\x69',
        '\x38\x33\x33\x31\x35\x30\x41\x4d\x4b\x4d\x68\x6b',
        '\x38\x38\x36\x37\x38\x30\x78\x75\x52\x76\x4c\x70',
        '\x67\x65\x74\x49\x6e\x74\x65\x67\x65\x72',
        '\x2e\x2f\x64\x79\x41\x70\x70',
        '\x31\x37\x38\x38\x31\x36\x32\x45\x78\x7a\x6b\x6a\x4f',
        '\x73\x68\x6f\x77',
        '\x6c\x6f\x67',
        '\x31\x39\x33\x39\x30\x6f\x6f\x74\x69\x62\x70',
        '\x74\x6f\x6b\x65\x72\x5f\x76\x69\x65\x77\x5f\x76\x69\x64\x65\x6f\x5f\x73\x65\x63\x6f\x6e\x64',
        '\x74\x6f\x6b\x65\x72\x5f\x76\x69\x65\x77\x5f\x76\x69\x64\x65\x6f\x5f\x6b\x65\x79\x77\x6f\x72\x64\x73',
        '\x67\x65\x74\x41\x72\x72\x61\x79',
        '\x31\x36\x64\x5a\x42\x58\x73\x4b',
        '\x32\x31\x36\x37\x37\x38\x37\x30\x79\x79\x77\x4c\x7a\x42',
        '\x31\x31\x34\x4c\x63\x65\x6f\x75\x47'
    ];
    a1_0x17a5 = function () {
        return _0x481597;
    };
    return a1_0x17a5();
}
(function (_0x3ff99b, _0x47cb46) {
    const _0x48674d = a1_0x106e, _0x4312a2 = _0x3ff99b();
    while (!![]) {
        try {
            const _0x5e86ee = -parseInt(_0x48674d(0xee)) / 0x1 + -parseInt(_0x48674d(0xe3)) / 0x2 * (-parseInt(_0x48674d(0xe9)) / 0x3) + -parseInt(_0x48674d(0xe7)) / 0x4 * (parseInt(_0x48674d(0xef)) / 0x5) + parseInt(_0x48674d(0xe0)) / 0x6 + -parseInt(_0x48674d(0xed)) / 0x7 + parseInt(_0x48674d(0xec)) / 0x8 * (-parseInt(_0x48674d(0xeb)) / 0x9) + parseInt(_0x48674d(0xe8)) / 0xa;
            if (_0x5e86ee === _0x47cb46)
                break;
            else
                _0x4312a2['push'](_0x4312a2['shift']());
        } catch (_0x2eb54e) {
            _0x4312a2['push'](_0x4312a2['shift']());
        }
    }
}(a1_0x17a5, 0x748a6));
function a1_0x106e(_0x3c6e2e, _0x22112f) {
    const _0x17a599 = a1_0x17a5();
    return a1_0x106e = function (_0x106ed4, _0x166735) {
        _0x106ed4 = _0x106ed4 - 0xe0;
        let _0x99ea30 = _0x17a599[_0x106ed4];
        return _0x99ea30;
    }, a1_0x106e(_0x3c6e2e, _0x22112f);
}
let dyApp = require(a1_0x53aa7a(0xf1)), config = {
        '\x74\x6f\x6b\x65\x72\x5f\x76\x69\x65\x77\x5f\x76\x69\x64\x65\x6f\x5f\x6b\x65\x79\x77\x6f\x72\x64\x73': Storage['\x67\x65\x74'](a1_0x53aa7a(0xe5)),
        '\x74\x6f\x6b\x65\x72\x5f\x76\x69\x65\x77\x5f\x76\x69\x64\x65\x6f\x5f\x73\x65\x63\x6f\x6e\x64': Storage[a1_0x53aa7a(0xf0)](a1_0x53aa7a(0xe4)),
        '\x74\x6f\x6b\x65\x72\x5f\x72\x75\x6e\x5f\x73\x65\x78': Storage[a1_0x53aa7a(0xe6)]('\x74\x6f\x6b\x65\x72\x5f\x72\x75\x6e\x5f\x73\x65\x78')
    };
console[a1_0x53aa7a(0xe2)](config, dyApp['\x67\x65\x74\x4e\x61\x6d\x65']()), FloatDialogs[a1_0x53aa7a(0xe1)]('\u63d0\u793a', a1_0x53aa7a(0xea));
//# sourceMappingURL=dy.js.map