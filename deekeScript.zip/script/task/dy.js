function a3_0x2a14(_0x16aaad, _0x2cdf47) {
    var _0x5e6a36 = a3_0x5e6a();
    return a3_0x2a14 = function (_0x2a1428, _0x26472b) {
        _0x2a1428 = _0x2a1428 - 0x109;
        var _0x4ade15 = _0x5e6a36[_0x2a1428];
        return _0x4ade15;
    }, a3_0x2a14(_0x16aaad, _0x2cdf47);
}
function a3_0x5e6a() {
    var _0x4d98e1 = [
        '16044gHOjsj',
        'getInteger',
        '1622485KMqlIS',
        '9084735AvhKgv',
        '请编写业务代码',
        '5536400fXmgDO',
        '3224096tdvZJu',
        '2671256cGranQ',
        'get',
        'log',
        'getArray',
        '37625094BwUVag',
        'vRhjl',
        '2934ammxMf',
        'toker_view_video_keywords',
        'ixKkl',
        '3nbINVt'
    ];
    a3_0x5e6a = function () {
        return _0x4d98e1;
    };
    return a3_0x5e6a();
}
(function (_0x1d398c, _0x51dc4a) {
    var _0x101b4f = a3_0x2a14, _0x47aab6 = _0x1d398c();
    while (!![]) {
        try {
            var _0x3f722a = parseInt(_0x101b4f(0x10c)) / 0x1 + parseInt(_0x101b4f(0x110)) / 0x2 + parseInt(_0x101b4f(0x109)) / 0x3 * (-parseInt(_0x101b4f(0x10f)) / 0x4) + parseInt(_0x101b4f(0x10d)) / 0x5 + -parseInt(_0x101b4f(0x117)) / 0x6 * (-parseInt(_0x101b4f(0x10a)) / 0x7) + parseInt(_0x101b4f(0x111)) / 0x8 + -parseInt(_0x101b4f(0x115)) / 0x9;
            if (_0x3f722a === _0x51dc4a)
                break;
            else
                _0x47aab6['push'](_0x47aab6['shift']());
        } catch (_0xad42e6) {
            _0x47aab6['push'](_0x47aab6['shift']());
        }
    }
}(a3_0x5e6a, 0xe5dc5), ((() => {
    'use strict';
    var _0x484ba7 = a3_0x2a14, _0x1226b3 = {
            'ixKkl': 'toker_view_video_second',
            'vRhjl': 'toker_run_sex',
            'Ulemy': _0x484ba7(0x10e)
        };
    var _0x37f9d5 = {
        'toker_view_video_keywords': Storage[_0x484ba7(0x112)](_0x484ba7(0x118)),
        'toker_view_video_second': Storage[_0x484ba7(0x10b)](_0x1226b3[_0x484ba7(0x119)]),
        'toker_run_sex': Storage[_0x484ba7(0x114)](_0x1226b3[_0x484ba7(0x116)])
    };
    console[_0x484ba7(0x113)](_0x37f9d5), FloatDialogs['show']('提示', _0x1226b3['Ulemy']);
})()));
//# sourceMappingURL=task/dy.js.map
//# sourceMappingURL=dy.js.map